#include <iostream>
using namespace std;
void inPut(int array[], int size);
void outPut(int array[], int size);
void minMax(int array[], int size);
void binarySort(int array[], int size);
void isSum(int array[], int size);
void isFrequency(int array[], int size);
int main()
{
    cout << "------------------------------------------------------------------------------------\n";
    cout << " PROGRAMME FOR INPUT,OUTPUT, SUM , SORTING ,MIN PRIICE OR MAX PRICE , FREQUENCY \n";
    cout << "------------------------------------------------------------------------------------\n";
    const int SIZE = 10;
    int array[SIZE];
    inPut(array, SIZE);
    outPut(array, SIZE);
    minMax(array, SIZE);
    binarySort(array, SIZE);
    isSum(array, SIZE);
    isFrequency(array, SIZE);
    return 0;
}
void inPut(int array[], int SIZE)
{
    cout << "ENTER A PRICE OF 10 ITEMS : \n";
    cout << endl;
    for (int i = 0; i < SIZE; i++)
    {
        cout << "ENTER A PRICE OF " << i + 1 << " ITEM : ";
        cin >> array[i];
    }
}
void outPut(int array[], int SIZE)
{
    cout << "\nPRICE OF 10 ITEMS : " << endl;
    for (int i = 0; i < SIZE; i++)
    {
        cout << "PRICE OF " << i + 1 << " ITEM : ";
        cout << array[i] << endl;
    }
}
void minMax(int array[], int SIZE)
{
    int min = array[0];
    int max = array[0];
    cout << " \nDISPLAY MAX AND MIN VALUE IS : " << endl;
    for (int i = 1; i < SIZE; i++)
    {
        if (max < array[i])
        {
            max = array[i];
        }
        if (min > array[i])
        {
            min = array[i];
        }
    }
    cout << "lowest price of item is  : ";
    cout << min;
    cout << endl;
    cout << "higest prize of item is  : ";
    cout << max;
}
void binarySort(int array[], int SIZE)
{
    int counter = 1;
    while (counter < SIZE)
    {
        for (int i = 0; i < SIZE - counter; i++)
        {
            if (array[i] > array[i + 1])
            {
                int temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
            }
        }

        counter++;
    }
    cout << "\nPRICE OF 10 ITEMS  AFTER SORT: " << endl;
    outPut(array, SIZE);
}
void isSum(int array[], int SIZE)
{
    int sum = 0;
    for (int i = 0; i < SIZE; i++)
    {
        sum += array[i];
    }
    cout << endl;
    cout << "TOTAL SUM OF ITEM PRICE: " << sum;
    cout << endl;
}
void isFrequency(int array[], int SIZE)
{
    cout << "\nFREQUENCY OF HIGEST ITEM \n";
    int max2 = 0;

    int counter1[10] = {0};
    for (int i = 0; i < SIZE; i++)
    {
        int temp = array[i];
        for (int j = 0; j < SIZE; j++)
        {
            if (temp == array[j])
            {
                counter1[i]++;
                cout << "\n counter value is \n";
                cout << counter1[i];
                cout << endl;
                if (max2 < counter1[i])
                {
                    max2 = counter1[i];
                }
            }
        }
    }

    for (int i = 0; i < SIZE; i++)
    {
        int j;
        for (j = 0; j < SIZE; j++)
        {
            if (array[i] == array[j])
            {
                break;
            }
        }
        if (i == j)
        {

            //       !!!!!!!!!!!!!!!!!!!!!!! note!!!!!!!!!!!!!!
            // if you want to show frequency of every number

            // if (counter1[i] >= max2  )
            // {
            //     cout << "ITEM NUMBER :" << array[i] << "         "
            //          << " AMOUNT" << counter1[i] << "   " << endl;
            // }

            // this code for show only heigest frequency and also if frequecy greater than 2
            if (counter1[i] >= max2 && counter1[i] > 1)
            {
                cout << "ITEM NUMBER :" << array[i] << "         "
                     << " AMOUNT" << counter1[i] << "   " << endl;
            }
        }
    }
}