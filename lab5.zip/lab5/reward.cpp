#include <iostream>
using namespace std;
int main()
{
    int counter = 0;
    const int SIZE = 10;
    int array[SIZE];
    int counter1[SIZE] = {0};
    int sum = 0;
    int max2 = 0;
    cout << "ENTER A PRICE OF 10 ITEMS  : ";
    cout << endl;
    for (int i = 0; i < SIZE; i++)
    {
        cout << "ENTER A PRICE OF " << i + 1 << " ITEM : ";
        cin >> array[i];
    }
    cout << "\n PRICE OF 10 ITEMS : " << endl;
    for (int i = 0; i < SIZE; i++)
    {
        cout << "PRICE OF " << i + 1 << " ITEM : ";
        cout << array[i] << endl;
    }
    int min = array[0];
    int max = array[0];
    cout << " DISPLAY MAX AND MIN VALUE IS : " << endl;
    for (int i = 1; i < SIZE; i++)
    {
        if (max < array[i])
        {
            max = array[i];
        }
    }
    cout << " lowest price of item is  : ";
    cout << min;
    cout << " height of item is  : ";
    cout << max;
    while (counter < SIZE)
    {
        for (int i = 0; i < SIZE - counter; i++)
        {
            if (array[i] > array[i + 1])
            {
                int temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
            }
        }

        counter++;
    }
    cout << "\n PRICE OF 10 ITEMS : " << endl;
    for (int i = 0; i < SIZE; i++)
    {

        cout << array[i] << "   ";
    }
    for (int i = 0; i < SIZE; i++)
    {
        sum += array[i];
    }
    cout << endl;
    cout << "TOTAL SUM : " << sum;
    cout << endl;
    for (int i = 0; i < SIZE; i++)
    {
        int temp = array[i];
        for (int j = 0; j < SIZE; j++)
        {
            if (temp == array[j])
            {
                counter1[i]++;
                if (max2 < counter1[i])
                {
                    max2 = counter1[i];
                }
            }
        }
    }

    for (int i = 0; i < SIZE; i++)
    {
        int j;
        for (j = 0; j < SIZE; j++)
        {
            if (array[i] == array[j])
            {
                break;
            }
        }
        if (i == j)
        {

            if (counter1[i] >= max2)
            {
                cout << "NUMBER :" << array[i] << "         "
                     << " AMOUNT" << counter1[i] << "   " << endl;
            }
        }
    }

    return 0;
}
