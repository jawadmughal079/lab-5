#include <iostream>
using namespace std;
void introOfPrograme();
void inputOfPrograme();
void swap(int &num1, int &num2);
int main()
{

    introOfPrograme();
    inputOfPrograme();
    return 0;
}
void introOfPrograme()
{
    cout << "----------------------------------------------------------------------------------------\n";
    cout << "\t\t\t\tswap Type Programe\n";
    cout << "----------------------------------------------------------------------------------------\n";
}
void inputOfPrograme()
{
    float num1 = 0, num2 = 0;
    cout << "Enter Number 1 : ";
    cin >> num1;
    cout << endl;
    cout << "Enter Number 2 : ";
    cin >> num2;
    cout << endl;
    cout << "Input from user \n";
    cout << endl;
    cout << "Number 1 from user : " << num1;
    cout << endl;
    cout << "Number 2 from user : " << num2;
    cout << endl;
    swap(num1, num2);
    cout << "\noutput \n ";
    cout << endl;
    cout << "Number 1 after swap : " << num1;
    cout << endl;
    cout << "Number 2 after swap : " << num2;
    cout << endl;
}
void swap(int &num1, int &num2)
{

    num2 = num1 + num2; //5+3
    num1 = num2 - num1; //8-5
    num2 = num2 - num1; //8-3
}