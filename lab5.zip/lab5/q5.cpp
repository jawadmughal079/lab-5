#include <iostream>
using namespace std;
void introOfPrograme();
void inputOfPrograme();
void reverse(int num1);
int main()
{

    introOfPrograme();
    inputOfPrograme();
    return 0;
}
void introOfPrograme()
{
    cout << "----------------------------------------------------------------------------------------\n";
    cout << "\t\t\t\t reverse Programe\n";
    cout << "----------------------------------------------------------------------------------------\n";
}
void inputOfPrograme()
{
    int num1 = 0;
    cout << "Enter a Number  : ";
    cin >> num1;
    cout << endl;

    cout << "Input from user \n";
    cout << endl;
    cout << "Number entered by user : " << num1;
    cout << endl;

    reverse(num1);
}
void reverse(int num1)
{
    int rev = 0;
    int div = 1;
    while (num1 != 0)
    {
        div = num1 % 10;
        rev = rev * 10 + div;
        num1 = num1 / 10;
    }
    cout << "Reverse values is : " << rev;
}