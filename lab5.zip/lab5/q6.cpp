#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    // file reading process is for integer
    ifstream integerFileName("integer.txt", ios::in);
    int integer = 0;
    integerFileName >> integer;

    //file write process for integer
    ofstream writeIntegerIntoFile("newfile.txt", ios::out);
    writeIntegerIntoFile << integer;
    writeIntegerIntoFile << endl;
    integerFileName.close();

    // file reading processs for character
    ifstream characterFileName("character.txt", ios::in);
    char character = ' ';
    characterFileName >> character;

    // file write process for character
    ofstream writeCharacterIntoFile("newFile.txt", ios::out | ios::app);
    writeCharacterIntoFile << character;
    writeCharacterIntoFile << endl;
    characterFileName.close();

    // file reading process for character Array
    ifstream characterArrayFileName("characterArray.txt", ios::in);
    char characterArray[100] = " ";
    characterArrayFileName.getline(characterArray, 100);

    // file write process for character arrray
    ofstream writeCharacterArrayIntoFile("newFile.txt", ios::out | ios::app);
    writeCharacterArrayIntoFile << characterArray;characterArrayFileName.close();
    return 0;
}