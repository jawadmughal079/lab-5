#include <iostream>
using namespace std;
void introOfPrograme();
void inputOfPrograme();
void factorial(int num1);
int main()
{

    introOfPrograme();
    inputOfPrograme();
    return 0;
}
void introOfPrograme()
{
    cout << "----------------------------------------------------------------------------------------\n";
    cout << "\t\t\t\tFactorial  Type Programe\n";
    cout << "----------------------------------------------------------------------------------------\n";
}
void inputOfPrograme()
{
    int num1 = 0;
    cout << "Enter a Number  : ";
    cin >> num1;
    cout << endl;

    cout << "Input from user \n";
    cout << endl;
    cout << "Number entered by user : " << num1;
    cout << endl;

    factorial(num1);
}
void factorial(int num1)
{
    int factorial = 1;
    cout << endl;
    cout << "Factorial of Number is : ";

    for (int i = 1; i <= num1; i++)
    {
        factorial *= i;
    }
    cout << factorial;
}