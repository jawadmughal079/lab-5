#include <iostream>
using namespace std;
void introOfPrograme();
void inputOfPrograme();
void calculater(float num1, float num2);
int main()
{

    introOfPrograme();
    inputOfPrograme();
    return 0;
}
void introOfPrograme()
{
    cout << "----------------------------------------------------------------------------------------\n";
    cout << "\t\t\t\tCalculater Type Programe\n";
    cout << "----------------------------------------------------------------------------------------\n";
}
void inputOfPrograme()
{
    float num1 = 0.0, num2 = 0.0;
    cout << "Enter Number 1 : ";
    cin >> num1;
    cout << endl;
    cout << "Enter Number 2 : ";
    cin >> num2;
    cout << endl;
    cout << "Input from user \n";
    cout << endl;
    cout << "Number 1 from user : " << num1;
    cout << endl;
    cout << "Number 2 from user : " << num2;
    cout << endl;
    calculater(num1, num2);
}
void calculater(float num1, float num2)
{
    cout << endl;
    cout << " Output : ";
    cout << endl;
    cout << "Sum of Numbers is      :" << num1 + num2 << endl;
    cout << "Subtract of Numbers is :" << num1 - num2 << endl;
    cout << "Product of Numbers is  :" << num1 * num2 << endl;
    cout << "Division of Numbers is :" << num1 / num2 << endl;
}