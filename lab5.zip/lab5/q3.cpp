#include <iostream>
using namespace std;
void introOfPrograme();
void inputOfPrograme();
void evenOddFinder(int num1);
int main()
{

    introOfPrograme();
    inputOfPrograme();
    return 0;
}
void introOfPrograme()
{
    cout << "----------------------------------------------------------------------------------------\n";
    cout << "\t\t\t\t Even and odd finder Programe\n";
    cout << "----------------------------------------------------------------------------------------\n";
}
void inputOfPrograme()
{
    int num1 = 0;
    cout << "Enter a Number  : ";
    cin >> num1;
    cout << endl;

    cout << "Input from user \n";
    cout << endl;
    cout << "Number entered by user : " << num1;
    cout << endl;

    evenOddFinder(num1);
}
void evenOddFinder(int num1)
{
    if (num1 % 2 == 0)
    {
        cout << "\nit is a Even number ";
    }
    else
    {
        cout << "\nit is a Odd number ";
    }
}